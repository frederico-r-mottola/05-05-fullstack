package br.senai.service;

import br.senai.model.Funcionario;

import java.util.List;

public interface FuncionarioServiceImpl {
    @Override
    public List<Funcionario> findAll(){return null;}

    @Override
    public Funcionario



}
