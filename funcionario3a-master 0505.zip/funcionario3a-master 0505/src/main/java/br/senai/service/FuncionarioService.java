package br.senai.service;

public interface FuncionarioService {
}
