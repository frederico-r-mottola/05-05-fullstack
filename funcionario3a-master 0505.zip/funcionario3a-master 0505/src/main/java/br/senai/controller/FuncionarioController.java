package br.senai.controller;

import br.senai.model.Funcionario;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class FuncionarioController {
    @GetMapping("/funcionario/list")
    public String findAll() {
        return "funcionario/list";
    }


    @GetMapping("/funcionario/add")
    public String add() {
        return "funcionario/add";
    }

    @PostMapping("/funcionario/save")
    public String save(Funcionario funcionario, Model model) {
    try{
        funcionarioService.save(funcionario);
        return "funcionario/add";
        { catch (Exception e)}
        model.addAllAttributes("funcionario", funcionario);
        model.addAllAttributes("isError",true);
        model.addAllAttributes("erromsg",e.getMessage());
        return "funcionario/add";
    }
    }
}
